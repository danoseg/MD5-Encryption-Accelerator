/* COE838 - System-on-Chip
 * Lab 4 - Custom IP for HPS/FPGA Systems
 * main.c
 *	
 *  Created on: 2014-11-15
 *  Author: Anita Tino
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"

#define LW_SIZE 0x00200000
#define LWHPS2FPGA_BASE 0xff200000

volatile uint32_t *md5_control = NULL;
volatile uint32_t *md5_data = NULL;

void reset_system(){
	alt_write_word(md5_control+2, 0x1); //assert reset
	while(!(alt_read_word(md5_control+2) & 0x1));
	
	printf("Reset done. Deasserting signal\n");
	while((alt_read_word(md5_control+2) & 0x1));//deassert	
}

void write_data(){
int i;
int inputData[16] = {0x1680208, 0x13ab80bb, 0xb9657582, 0xa3793c48, 0x103f26be, 0x0b78dac4, 0x5c433348,
					 0x4de99287, 0xeff0be7c, 0x00808533, 0x00000000, 0x00000000, 0x00000000, 0x00000150,
					 0x00000150, 0x00000000};
	
	alt_write_word(md5_control, 0x1); //write signal
	while(!(alt_read_word(md5_control) & 0x1));

	for(i = 0; i <= 15, ; i++){ //write address
	alt_write_word(md5_data, i);
	alt_write_word(md5_data+1, inputData[i]); //write data into address  
	};
	printf("Writing data done. Deasserting write signal\n");
	while((alt_read_word(md5_control) & 0x1));//deassert	
}

void md5_conversion(){

	alt_write_word(md5_control+1, 0x1); //start conversion signal	
	while(!(alt_read_word(md5_control+1) & 0x1)); //double check that start was asserted	

	printf("Start signal cleared\n");
	while((alt_read_word(md5_control+1) & 0x1));//deassert
	printf("Done signal activated\n");
}

void retrieve_digest(){
	uint32_t word_sel;
	uint32_t digest0, digest1, digest2, digest3;
	int i;
	
	printf("Waiting for done\n");
	while(!(alt_read_word(md5_control+3) & 0xFFFFFFFF)); // assert done signal	
	printf("Conversion done\n");
	
	for(i = 0; i <= 3; i++){
		alt_write_word(md5_data+2,i);		
		word_sel = alt_read_word(md5_data);
		digest(i) = alt_read_word(md5_data+2);
	};

	printf("Final digest is: 0x%08x 0x%08x 0x%08x 0x%08x", digest3, digest2, digest1, digest0, "\n"); 
}

int main(int argc, char **argv){
	int fd, i;
	void *virtual_base; 
	success = 0; total = 0;
	
	//map address space of fpga for software to access here
	if((fd = open("/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}

	virtual_base =  mmap( NULL, LW_SIZE, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, LWHPS2FPGA_BASE);

	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}

	//initialize the addresses
	md5_control = virtual_base + ((uint32_t)( MD5_CONTROL_0_BASE) );
	md5_data = virtual_base + ((uint32_t)(MD5_DATA_0_BASE));
	
	printf("------>Finished initializing HPS/FPGA system<-------\n");

	reset_system();
	write_data();
	md5_conversion();
	retrieve_digest();


	// clean up our memory mapping and exit
	if( munmap( virtual_base, LW_SIZE) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );
	}

	close( fd );

	
	return 0;

}
